package group.com.fconnect;public class MonthClass {
    private String M1;
    private String M2;
    private String M3;
    private String M4;
}
