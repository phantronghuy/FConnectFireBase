package group.com.fconnect;public class InformationChuSan {
    public static String Id_ChuSan;
    public static String TenChuSan;
    public static String CCCD;
    public static String SDT;
    public static String UserName;
    public static String MatKhau;


}
