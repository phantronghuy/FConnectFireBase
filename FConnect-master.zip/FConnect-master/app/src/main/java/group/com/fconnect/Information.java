package group.com.fconnect;public class Information {
    public static String name;
    public static String username;
    public static String password;
    public static String email;
    public static String sdt;
}
